document = """
  a: 1
  b:
    c: 3
    d: 4
"""

def Handler():
    return str(document)
